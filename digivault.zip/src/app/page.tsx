import Link from "next/link";
import { Search, ShieldCheck, Zap, Vault } from "lucide-react";

export default function Home() {
  return (
    <main>
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Link href="/" className="flex items-center gap-2 font-display text-xl font-semibold">
          <Vault className="h-6 w-6 text-accent" aria-hidden /> DigiVault
        </Link>
        <nav className="flex items-center gap-6 text-sm text-white/70">
          <Link href="/products" className="hover:text-white">Products</Link>
          <Link href="/track" className="hover:text-white">Track order</Link>
          <Link href="/login" className="rounded-full border border-line px-4 py-1.5 hover:border-accent hover:text-white">Sign in</Link>
        </nav>
      </header>

      <section className="mx-auto max-w-6xl px-5 pb-24 pt-20 sm:pt-32">
        <h1 className="max-w-3xl font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-7xl">
          Digital goods, paid your way, delivered once verified.
        </h1>
        <p className="mt-6 max-w-xl text-lg text-white/60">
          Pay with Binance or BaridiMob. Every payment is checked by hand, and your codes arrive only after approval.
        </p>
        <form action="/products" className="mt-10 flex max-w-xl items-center gap-3 rounded-2xl border border-line bg-panel px-4 py-3 focus-within:border-accent">
          <Search className="h-5 w-5 text-white/40" aria-hidden />
          <input name="q" placeholder="Search gift cards, games, software" aria-label="Search products"
            className="w-full bg-transparent outline-none placeholder:text-white/35" />
          <button className="rounded-xl bg-accent px-4 py-1.5 text-sm font-medium">Search</button>
        </form>
        <ul className="mt-16 grid gap-4 text-sm text-white/70 sm:grid-cols-2">
          <li className="flex items-start gap-3 border-t border-line pt-4"><ShieldCheck className="mt-0.5 h-5 w-5 text-accent" aria-hidden />Codes stay locked until an admin approves your payment.</li>
          <li className="flex items-start gap-3 border-t border-line pt-4"><Zap className="mt-0.5 h-5 w-5 text-accent" aria-hidden />Track any order with its private link, no account needed.</li>
        </ul>
      </section>
    </main>
  );
}
